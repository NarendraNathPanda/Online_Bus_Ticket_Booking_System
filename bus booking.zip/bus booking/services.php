<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>services</title>
   
    <link rel="stylesheet" type="text/css" href="css/services.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
</head>
<body>
    <header>
    	 <div class="title">
                <h1>Easy Journey</h1>
            </div>
            <div class=main>

   <a href="0index.php"><i class="fas fa-home"></i> Home</a>



<div class="box">

<h1>Registered Office</h1>
<p>Duttapukur - Nilganj Road, Kolkata , West Bengal , PIN - 700126</p><br>
<h1>Corporate Office</h1>
<p>Barasat - Barrakpore Road, Kolkata , West Bengal , PIN - 700124</p><br>
<p>

</div>

	
        </header>
    </body>
    </html>